/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import Modelo.Funcionario;

/**
 *
 * @author mikhe
 */
public class FuncionarioControle {
    public static java.util.List<Object[]> obterTodos() {
        java.util.List<Object[]> retorno = new java.util.ArrayList<>();
        java.util.List<Modelo.Funcionario> funcionario = modelo.dao.FuncionarioDAO.listarTodos();
        Iterable<Funcionario> Funcionario;
        for (Modelo.Funcionario f : funcionario) {
            retorno.add(new Object[]{f.getId(), f.getNome(), f.getCpf(), f.getSexo(), f.getIdade(), f.getCargo(), f.getSetor(), 
                f.getAdmissao(), f.getCidade(), f.getSalario()});
        }
        return retorno;
    }
}
