/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dao;

import Modelo.Funcionario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import util.RealizaConexao;

/**
 *
 * @author lins
 */
public class FuncionarioDAO {
    
    public void Cadastrar (Funcionario Fun) throws ClassNotFoundException, SQLException{
        Connection con = RealizaConexao.getConexao(); //Criar Classe RealizaConexao
        PreparedStatement comando = con.prepareStatement("insert into Funcionario (Id,Nome,Sexo,Idade,Admissao, Cidade, Cargo, Salario, Setor,CPF) values(?,?,?,?,?,?,?,?,?,?)");
        comando.setInt(1, Fun.getId());
        comando.setString(2, Fun.getNome());
        comando.setString(3, Fun.getSexo());
        comando.setInt(4, Fun.getIdade());
        comando.setString(5, Fun.getAdmissao()); //Verificar para mudar para DATE
        comando.setString(6, Fun.getCidade());
        comando.setString(7, Fun.getCargo());
        comando.setDouble(8, Fun.getSalario());
        comando.setString(9, Fun.getSetor());
        comando.setInt(10, Fun.getCpf());
        comando.execute();
        con.close();
    }
    public void Deletar(Funcionario Fun)throws ClassNotFoundException, SQLException{
        Connection con = RealizaConexao.getConexao();//Criar Classe RealizaConexao
        PreparedStatement comando = con.prepareStatement ("delete from Funcionario where id = ?");
        comando.setInt(1, Fun.getId());
        comando.execute();
        con.close();
    }
    public void atualizar(Funcionario Fun) throws ClassNotFoundException, SQLException {
        Connection con = RealizaConexao.getConexao(); //Criar Classe RealizarConexao
        PreparedStatement comando = con.prepareStatement ("update Funcionario  set Nome = ?, Sexo = ?, Idade = ?, Admissao = ?, Cidade = ?, Cargo = ?, Salario = ?, Setor = ?, CPF = ? where Id = ? ");
        comando.setInt(10, Fun.getId());
        comando.setString(1, Fun.getNome());
        comando.setString(2, Fun.getSexo());
        comando.setInt(3, Fun.getIdade());
        comando.setString(4, Fun.getAdmissao()); //Verificar para mudar para DATE
        comando.setString(5, Fun.getCidade());
        comando.setString(6, Fun.getCargo());
        comando.setDouble(7, Fun.getSalario());
        comando.setString(8, Fun.getSetor());
        comando.setInt(9, Fun.getCpf());
        comando.execute();
        con.close();
    }
    //private static final String LISTAR = "SELECT * FROM crud.funcionario"; UTILIZADO PARA  INSERIR COMANDO ATRAVÉS DA VARIAVEL LISTAR
    public static java.util.List<Modelo.Funcionario> listarTodos() {
        java.sql.Connection con = null;
        java.sql.PreparedStatement pstmt = null;
        java.sql.ResultSet rs = null;
        java.util.List<Modelo.Funcionario> retorno = new java.util.ArrayList<>();
        
        try{
            con = util.RealizaConexao.getConexao();
            pstmt = con.prepareStatement("SELECT * FROM crud.funcionario");
            rs = pstmt.executeQuery();
            while (rs.next()){
            Modelo.Funcionario fun = new Modelo.Funcionario();
            fun.setId(rs.getInt("Id"));
            fun.setNome(rs.getString("Nome"));
            fun.setSexo(rs.getString("Sexo"));
            fun.setIdade(rs.getInt("Idade"));
            fun.setAdmissao(rs.getString("Admissao"));//VERIFICAR A QUESYAO DA DATA
            fun.setCidade(rs.getString("Cidade"));
            fun.setCargo(rs.getString("Cargo"));
            fun.setSalario(rs.getDouble("Salario"));
            fun.setSetor(rs.getString("Setor"));
            fun.setCpf(rs.getInt("CPF"));
            retorno.add(fun);
            }
        } catch (ClassNotFoundException | SQLException err){
            throw new RuntimeException(err);
        }
        return retorno;
    }/*
    public List<Funcionario> consultarTodos(Funcionario Fun) throws ClassNotFoundException, SQLException{
        Connection con = RealizaConexao.getConexao();//CRIAR CLASSE REALIZAR CONEXAO
        PreparedStatement comando = con.prepareStatement("select *from Funcinarios");
        ResultSet rs = comando.executeQuery();
        List<Funcionario> lfun = new ArrayList<Funcionario>();
        int i =0;
        while (rs.next()){
            Funcionario fun = new Funcionario();
            fun.setId(rs.getInt("Id"));
            fun.setNome(rs.getString("Nome"));
            fun.setSexo(rs.getString("Sexo"));
            fun.setIdade(rs.getInt("Idade"));
            fun.setAdmissao(rs.getString("Admissao"));//VERIFICAR A QUESYAO DA DATA
            fun.setCidade(rs.getString("Cidade"));
            fun.setCargo(rs.getString("Cargo"));
            fun.setSalario(rs.getDouble("Salario"));
            fun.setSetor(rs.getString("Setor"));
            fun.setCpf(rs.getInt("CPF"));
            lfun.add(fun);
            i++;
        }
        System.out.println("Cont..."+i);
        con.close();
        return lfun;
        
    }*/
    public Funcionario consultarById(Funcionario fun) throws ClassNotFoundException, SQLException{
        Connection con = RealizaConexao.getConexao();
        PreparedStatement comando = con.prepareStatement("select * from Funcionario where id = ?");
        comando.setInt(1,fun.getId());
        ResultSet rs = comando.executeQuery();
        Funcionario f = new Funcionario();
        if (rs.next()){
            
            f.setId(rs.getInt("Id"));
            f.setNome(rs.getString("Nome"));
            f.setSexo(rs.getString("Sexo"));
            f.setIdade(rs.getInt("Idade"));
            f.setAdmissao(rs.getString("Admissao"));//VERIFICAR A QUESYAO DA DATA
            f.setCidade(rs.getString("Cidade"));
            f.setCargo(rs.getString("Cargo"));
            f.setSalario(rs.getDouble("Salario"));
            f.setSetor(rs.getString("Setor"));
            f.setCpf(rs.getInt("CPF"));   
            }
        con.close();
        return f;}
        
    
    
    
    
    
}
