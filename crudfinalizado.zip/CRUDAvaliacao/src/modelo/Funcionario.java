/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author lins
 */
public class Funcionario {
                                  
    private int Id;
    private String Nome;
    private String Sexo;
    private int Idade;
    private int CPF; // verficar se deve ser int/float ou double
    private String Admissao;// Verificar de como utilizar Data em java. e Passar para o SGBD
    private String Cidade;
    private String Cargo;
    private double Salario;
    private String Setor;
    
    public void setId(int Id)
    {this.Id=Id;}
    public int getId()
    {return(Id);}
    
    public void setNome(String Nome)
    {this.Nome=Nome;}
    public String getNome()
    {return(Nome);}
    
    public void setSexo(String Sexo)
    {this.Sexo=Sexo;}
    public String getSexo()
    {return(Sexo);}
    
    public void setIdade(int Idade)
    {this.Idade=Idade;}
    public int getIdade()
    {return(Idade);}
    
    public void setCpf(int CPF)
    {this.CPF=CPF;}
    public int getCpf()
    {return(CPF);}
    
    public void setAdmissao(String Admissao)      
    {this.Admissao=Admissao;}
    public String getAdmissao()
    {return(Admissao);}
    
    public void setCidade(String Cidade)
    {this.Cidade=Cidade;}
    public String getCidade()
    {return(Cidade);}
    
    public void setCargo(String Cargo)
    {this.Cargo=Cargo;}
    public String getCargo()
    {return(Cargo);}
    
    public void setSalario(double Salario)
    {this.Salario=Salario;}
    public double getSalario()
    {return(Salario);}
    
    public void setSetor(String Setor)
    {this.Setor=Setor;}
    public String getSetor()
    {return(Setor);}
    
   
            
    
    
    
  
    
    
}
