/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package avaliacaopolimorfismo;

/**
 *
 * @author lins
 */
public class AvaliacaoPolimorfismo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cliente cli;
        
        ClienteUrbano  cu1=new ClienteUrbano("Maria da Silva","Rua Sei La,10 - Mogi das Cruzes", 220.00, 240.00);
        cli=cu1;
        cli.CalcularValorConta();
        cli.AplicarAliquota();
        System.out.println("Nome.........: "+cli.getNome());
        System.out.println("Valor Conta..: "+cli.getValorconta());
    }
    
}
