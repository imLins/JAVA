/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package avaliacaopolimorfismo;

/**
 *
 * @author lins
 */
public class ClineteRural extends Cliente {
    
    public ClineteRural(String nome, String endereco, double qtdaguaconsumida, double qtdesgotoproduzido, double valorconta)
    {
        super(nome, endereco, qtdaguaconsumida, qtdesgotoproduzido);
    }
    
    public void CalcularValorConta()
    {
        double ax;
        ax= (qtdaguaconsumida+qtdesgotoproduzido)*3.5;
        qtdaguaconsumida=ax;
    }
    public double AplicarAliquota()
    {
        double va;
        if (qtdaguaconsumida>=20)
        { 
            
            va= qtdaguaconsumida * 1.03;
        }
        else 
        {
            
            va= qtdaguaconsumida * 1.15;
        }
        return va;
          
     }
    
  
    
}
