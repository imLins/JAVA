/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package avaliacaopolimorfismo;

/**
 *
 * @author lins
 */
public class Cliente {
    protected String nome;
    protected String endereco;
    protected double qtdaguaconsumida;
    protected double qtdesgotoproduzido;
    protected double valorconta;
    
    public Cliente(String nome, String endereco, double qtdaguaconsumida, double qtdesgotoproduzido)
    {
        this.endereco = endereco;
        this.nome = nome;
        this.qtdaguaconsumida= qtdaguaconsumida;
        this.qtdesgotoproduzido = qtdesgotoproduzido;
        //this.valorconta = valorconta;
        
    }
    public void setNome(String n)
    {nome=n;}
    
    public void setEndereco(String e)
    {endereco=e;}
    
    public void setQtdaguaconsumida(double A)
    {qtdaguaconsumida=A;}
    
    public void setQtdesgotoproduzido(double e)
    {qtdesgotoproduzido= e;}
    
    public String getNome()
    {return(nome);}
    
    public String getEndereco()
    {return(endereco);}
    
    public double getValorconta()
    {return(valorconta);}
    
    public double getQtdAguaConsumida()
    {return(qtdaguaconsumida);}
    
    public double getQtdEsgotoProduzido()
    {return(qtdesgotoproduzido);}
    
    public void CalcularValorConta()
    {   
    }
    public double AplicarAliquota()
    {
     return (0);
    }
    
}
