/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package avaliacaopolimorfismo;

/**
 *
 * @author lins
 */
public class ClienteUrbano extends Cliente {
    
    public ClienteUrbano(String nome, String endereco, double qtdaguaconsumida, double qtdesgotoproduzido)
    {
        super(nome, endereco, qtdaguaconsumida, qtdesgotoproduzido);
    }
    public void CacularValorConta()
    {
        //double ax;
        valorconta= (qtdaguaconsumida+qtdesgotoproduzido)*2.5;
        
    }
    @Override
    public double AplicarAliquota()
    {
        double va;
        va=0;
        if (qtdaguaconsumida >= 200)
        {
            va= valorconta -(valorconta*0.1);
        }
        else
        {
            va= valorconta - (valorconta *0.05);
        }
        return va;
    }
}
    
    


    
    
    
